﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagement_ConsoleClient
{
     class Program
    {
        // Act as Http Client
        static HttpClient client = new HttpClient();

        static void Main(string[] args)
        {
            // Specify WebAPI base address
            client.BaseAddress = new Uri("https://localhost:7040");

            // Specify headers
            var val = "application/json";
            var media = new MediaTypeWithQualityHeaderValue(val);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(media);

            // Make the calls - Post, Get, Update and Delete
            try
            {


                //// create
                //var TaskDetails = new TaskData()
                //{
                //    taskName = "test data",
                //    startDate = DateTime.Now,
                //    endDate = DateTime.Now.AddDays(10)
                //};

                //var message = string.Empty;

                //message = AddTask(TaskDetails);
                //Console.WriteLine($"Create: {message}");

                // read
                Console.WriteLine("List Tasks");
                List<TaskData> taskdata = GetTasks();
                foreach (var item in taskdata)
                {

                    Console.WriteLine($"==============================");
                    Console.WriteLine($"Id: {item.id}");
                    Console.WriteLine($"TaskName: {item.taskName}");
                    Console.WriteLine($"StartDate: {item.startDate.ToString()}");
                    Console.WriteLine($"EndDate: {item.endDate.ToString()}");
                }
                // update
                //var updateTaskDetails = new TaskData()
                //{
                //    taskName = "Updated",
                //    startDate = DateTime.Now,
                //    endDate = DateTime.Now.AddDays(10)
                //};
                //var result = UpdateTaskById(12,updateTaskDetails);

                // delete
                Console.WriteLine(DeleteTaskById(14));
            }
            catch(Exception ex)
            {

            }
            Console.ReadKey();
        }

        private static string DeleteTaskById(int id)
        {
            var action = "api/Tasks/get-all-tasks";
            var request = client.GetAsync(action);
            var response = request.Result.Content.ReadAsAsync<List<TaskData>>();
            foreach (var item in response.Result)
            {
                if (item.id == id)
                {
                    action = $"api/Tasks/delete-task-by-id/{id}";
                    request = client.DeleteAsync(action);
                    var result = request.Result.Content.ReadAsStringAsync();
                    return response.Result.ToString();
                }
            }
            return "Data Not Found";
        }


        private static string UpdateTaskById(int id,TaskData data)
        {
            var action = "api/Tasks/get-all-tasks";
            var request = client.GetAsync(action);
            var response = request.Result.Content.ReadAsAsync<List<TaskData>>();
            foreach(var item in response.Result)
            {
                if (item.id == id)
                {
                    item.taskName = data.taskName;
                    item.startDate = data.startDate;
                    item.endDate = data.endDate;
                    action = $"api/Tasks/update-task-by-id/{id}";
                    request = client.PutAsJsonAsync(action, item);
                    var result = request.Result.Content.ReadAsStringAsync();
                    return response.Result.ToString();
                }
            }
            return "Data Not Found";
        }

        private static List<TaskData> GetTasks()
        {
            var action = "api/Tasks/get-all-tasks";
            var request = client.GetAsync(action);
            var response = request.Result.Content.ReadAsAsync<List<TaskData>>();

            return response.Result;
        }

        private static string AddTask(TaskData taskDetails)
        {
            var action = "api/Tasks/add-task";
            var request = client.PostAsJsonAsync(action,taskDetails);
            var response = request.Result.Content.ReadAsStringAsync();
            return response.Result;
        }
    }
}
